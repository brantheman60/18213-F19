This directory contains material to help learn the basic principles of
the PxyDrive proxy testing framework.

Files:

proxy-ref proxy-corrupt proxy-overrun proxy-strip

      Executable proxies.  One that is fully functional, and three
      with known bugs

pxy/

      Copy of PxyDrive files

sXX-YYY.cmd

      PxyDrive command files for use in the tutorial

script.txt

      Description of what commands to execute and what to look for in
      the results

