/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_179()
{
    return 3284633928U;
}

unsigned addval_310(unsigned x)
{
    return x + 2496104776U;
}

void setval_349(unsigned *p)
{
    *p = 2445773128U;
}

unsigned getval_462()
{
    return 3281031192U;
}

unsigned addval_428(unsigned x)
{
    return x + 2425378935U;
}

unsigned getval_407()
{
    return 3653472280U;
}

unsigned getval_221()
{
    return 566450282U;
}

unsigned getval_212()
{
    return 2428995912U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_338(unsigned *p)
{
    *p = 3676357033U;
}

unsigned addval_138(unsigned x)
{
    return x + 3374372489U;
}

unsigned addval_412(unsigned x)
{
    return x + 3527988873U;
}

unsigned addval_300(unsigned x)
{
    return x + 2429192564U;
}

void setval_322(unsigned *p)
{
    *p = 3353381192U;
}

unsigned addval_302(unsigned x)
{
    return x + 2447411528U;
}

unsigned addval_129(unsigned x)
{
    return x + 2430634312U;
}

unsigned getval_455()
{
    return 2428602854U;
}

unsigned getval_250()
{
    return 3677407881U;
}

unsigned getval_374()
{
    return 2428602778U;
}

void setval_106(unsigned *p)
{
    *p = 3227566473U;
}

void setval_466(unsigned *p)
{
    *p = 3526934793U;
}

unsigned addval_382(unsigned x)
{
    return x + 2430634344U;
}

unsigned addval_319(unsigned x)
{
    return x + 3268839756U;
}

void setval_488(unsigned *p)
{
    *p = 3252717896U;
}

unsigned addval_196(unsigned x)
{
    return x + 4056140441U;
}

unsigned getval_215()
{
    return 3677935305U;
}

unsigned getval_326()
{
    return 2026097321U;
}

void setval_450(unsigned *p)
{
    *p = 3534018185U;
}

unsigned addval_459(unsigned x)
{
    return x + 3531131529U;
}

void setval_239(unsigned *p)
{
    *p = 3221804673U;
}

unsigned getval_130()
{
    return 3526416009U;
}

void setval_391(unsigned *p)
{
    *p = 3599350617U;
}

void setval_169(unsigned *p)
{
    *p = 3223374473U;
}

unsigned addval_143(unsigned x)
{
    return x + 3286272328U;
}

unsigned addval_435(unsigned x)
{
    return x + 2430638408U;
}

void setval_183(unsigned *p)
{
    *p = 3223372185U;
}

void setval_293(unsigned *p)
{
    *p = 3400135850U;
}

void setval_327(unsigned *p)
{
    *p = 3375939979U;
}

unsigned addval_409(unsigned x)
{
    return x + 583516553U;
}

unsigned addval_124(unsigned x)
{
    return x + 3269495112U;
}

unsigned getval_321()
{
    return 3374369433U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
