/*
 * 15-213/18-213: Introduction to Computer Systems
 * Name: Brandon Wang
 * AndrewID: bcwang
 *
 * Sources:
 * -Lecture 22: Network Programming Basics
 *  Starter code for main routine, ...?????
 */

/* Some useful includes to help you get started */

#include "csapp.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <ctype.h>
#include <stdbool.h>
#include <inttypes.h>
#include <unistd.h>
#include <assert.h>

#include <pthread.h>
#include <signal.h>
#include <errno.h>
#include <netinet/in.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>

/*
 * Debug macros, which can be enabled by adding -DDEBUG in the Makefile
 * Use these if you find them useful, or delete them if not
 */
#ifdef DEBUG
#define dbg_assert(...) assert(__VA_ARGS__)
#define dbg_printf(...) fprintf(stderr, __VA_ARGS__)
#else
#define dbg_assert(...)
#define dbg_printf(...)
#endif

/*
 * Max cache and object sizes
 * You might want to move these to the file containing your cache implementation
 */
#define MAX_CACHE_SIZE (1024*1024)
#define MAX_OBJECT_SIZE (100*1024)

/* Typedef for convenience */
typedef struct sockaddr SA;

/* List of helper functions */
void parse_uri(char *uri, char *hostname, char *pathname, int *port);
void serve(int fd);
void make_requesthdrs(char *buf, char *hostname, rio_t *rio);

/*
 * Strings to use for the main headerw.
 * Don't forget to terminate with \r\n!
 */
static const char *header_user_agent = "User-Agent: Mozilla/5.0"
       " (X11; Linux x86_64; rv:3.10.0) Gecko/20191101 Firefox/63.0.1";
static const char *header_connect = "Connection: close";
static const char *header_proxy_connect = "Proxy-Connection: close";
static const char *carr_newl = "\r\n";

static bool verbose = false;

/*
 * parse_uri: decompose uri into host name, path name, and port number
 * Input: char *uri (received uri)
 *        char *hostname (host name (uninitialized))
 *        char *pathname (path name (uninitialized))
 *        int *port (pointer to port number (uninitialized))
 * Output: void
 */
void parse_uri(char *uri, char *hostname, char *pathname, int *port)
{
    uri += strlen("http://"); //assume begins with http://
    char *pathbegin = strstr(uri, "/");
    int host_len = (int) (pathbegin - uri);
    strncpy(hostname, uri, host_len);
    hostname[host_len] = '\0';
    strcpy(pathname, pathbegin);

    if(strchr(hostname, ':') != NULL) //port number is included
    {
      char *token = strtok(hostname, ":");
      strcpy(hostname, token);
      token = strtok(NULL, " ");
      *port = atoi(token);
    }
    else *port = 80; //default port
}

/*
 * serve: after establishing a connection with the client, form a
 *        connection with the server acting like the client
 * Input: int clientfd (buffer descriptor / client port)
 * Output: void
 */
void serve(int clientfd)
{
    char buf_client[MAXLINE] = "", buf_server[MAXLINE] = "",
         uri[MAXLINE] = "";
    char method[MAXBUF] = "", hostname[MAXBUF] = "",
         pathname[MAXBUF] = "", version[MAXBUF] = "";
    int port;
    rio_t rio_client, rio_server;

    //set all buffers to 0
    memset(buf_client, 0, sizeof(buf_client));
    memset(buf_server, 0, sizeof(buf_server));
    memset(uri, 0, sizeof(uri));
    memset(method, 0, sizeof(method));
    memset(hostname, 0, sizeof(hostname));
    memset(pathname, 0, sizeof(pathname));
    memset(version, 0, sizeof(version));


    rio_readinitb(&rio_client, clientfd);
    if (!rio_readlineb(&rio_client, buf_client, MAXLINE))
    {
        if(verbose) printf("Error with reading client request\n");
        return;
    }

    if(verbose)
      printf("Initial request by client had header: %s\n", buf_client);

    //parse buf_client into GET, URI, and Version
    sscanf(buf_client, "%s %s %s", method, uri, version);
    if(strcmp(method, "GET"))
    {
        printf("Error with initial request\n");
        return;
    }
    if(strcmp(version, "HTTP/1.0") && strcmp(version, "HTTP/1.1"))
    {
        printf("Error with initial request\n");
        return;
    }
    parse_uri(uri, hostname, pathname, &port);
    if(verbose)
    {
      printf("URI: %s\n", uri);
      printf("Hostname: %s\n", hostname);
      printf("Pathname: %s\n", pathname);
      printf("Port: %d\n", port);
    }

    //open connection w/ and send request to desired server
    char *port_string = Calloc(5, sizeof(char)); //size of 5 digits
    sprintf(port_string, "%d", port);
    int serverfd = open_clientfd(hostname, port_string);
    if(serverfd < 0)
    {
        if(verbose) printf("Error with sending client request\n");
        return;
    }

    //fill buf_server with response headers
    strcat(buf_server, method);
    strcat(buf_server, " ");
    strcat(buf_server, pathname);
    strcat(buf_server, " HTTP/1.0\r\n");
    make_requesthdrs(buf_server, hostname, &rio_client);

    //set connection to server and write data to server
    rio_readinitb(&rio_server, serverfd);
    rio_writen(serverfd, buf_server, strlen(buf_server));
    sleep(3); //!!!!!
    if(verbose)
      printf("Message received by server had header: %s", buf_server);

    //read any response data from server and send to client
    int response_len = 0, read_len;
    while((read_len = rio_readnb(&rio_server, buf_server, MAXLINE)) > 0)
    {
        if(verbose)
          printf("Message sent by server had header: %s", buf_server);
        response_len += read_len;
        rio_writen(clientfd, buf_server, read_len);
        if(verbose)
          printf("Message received by client had header %s", buf_server);
    }

    //Close connection with server
    close(serverfd);
    return;
}

/*
 * make_requesthdrs: form the whole output request message and store in buf
 *                   also prints the input headers!
 * Input: char *buf (buffer, already with GET header, to store headers)
 *        char *hostname (host name)
 *        rio_t *rio (rio struct with all request headers)
 * Output: void
 */
void make_requesthdrs(char *buf, char *hostname, rio_t *rio)
{
    char buf_tmp[MAXLINE];

    //pass through any other headers
    while(strcmp(buf_tmp, "\r\n"))
    {
        rio_readlineb(rio, buf_tmp, MAXLINE);
        if(verbose) printf("%s", buf_tmp);
        if( !strstr(buf_tmp, "GET") &&
            !strstr(buf_tmp, "User-Agent") &&
            !strstr(buf_tmp, "Connection") &&
            !strstr(buf_tmp, "Proxy-Connection"))
        {
            strcat(buf, buf_tmp);
        }
    }

    //pass in main headers
    if(!strstr(buf, "Host:"))
    {
        strcat(buf, "Host: ");
        strcat(buf, hostname);
        strcat(buf, carr_newl);
    }

    strcat(buf, header_user_agent);
    strcat(buf, carr_newl);

    strcat(buf, header_proxy_connect);
    strcat(buf, carr_newl);

    strcat(buf, header_connect);
    strcat(buf, carr_newl);

    return;
}

int main(int argc, char** argv) {
    //Ignore SIGPIPE signal, which normally would terminate program
    Signal(SIGPIPE, SIG_IGN);

    int ch;
    while((ch = getopt(argc, argv, "v")) != -1)
    {
      switch (ch) {
      case 'v': // Verbose
        verbose = true;
        break;
      case 'V': // Verbose
        verbose = true;
        break;
      default:
        break;
      }
    }

    if (argc < 2)
    {
        if(verbose) printf("No port number provided\n");
        exit(1);
    }
    uint16_t portno = verbose ? atoi(argv[2]) : atoi(argv[1]);
    if(portno < 1024)
    {
       if(verbose) printf("Port number must be between 1024 and 32768\n");
       exit(1);
    }

    int listenfd, connfd; //server and client descriptors/ports
    socklen_t clientlen;
    struct sockaddr_storage clientaddr;
    char client_hostname[MAXLINE], client_port[MAXLINE];
    //opens and returns listening socket on portno
    listenfd = open_listenfd(verbose ? argv[2] : argv[1]);
    if(listenfd < 0)
    {
        if(verbose) printf("Error with creating listening socket\n");
        exit(1);
    }

    while (1) {
      // accept connection request from client and stores client port
      clientlen = sizeof(struct sockaddr_storage);
      connfd = accept(listenfd, (SA *)&clientaddr, &clientlen);

      getnameinfo((SA *) &clientaddr, clientlen,
                  client_hostname, MAXLINE,
                  client_port, MAXLINE, 0);

      if(verbose)
        printf("Connected to (%s, %s)\n", client_hostname, client_port);

      //send request to desired server by acting as a client
      serve(connfd); //begin client/server session
      close(connfd); //end client/server session
    }

    return 0;
}
